package com.royole.drawingdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.royole.drawinglib.RyDrawingManager;
import com.royole.drawinglib.interfaces.IDrawingBusinessListener;

import java.util.List;

import butterknife.BindViews;
import butterknife.ButterKnife;

/**
 * File description.
 *
 */
public class BusinessActivity extends Activity implements View.OnClickListener,
        IDrawingBusinessListener {
    final static String SEPRITE = ",";
    @BindViews({R.id.get_battery_info, R.id.get_dev_desc, R.id.get_width, R.id.get_height})
    List<Button> mBtnList;
    @BindViews({R.id.get_battery_info_result, R.id.get_dev_desc_result, R.id.width_text, R.id
            .height_text})
    List<TextView> mTvList;
    RyDrawingManager ryManager;
    ButterKnife.Action<View> CLICK_ACTION = new ButterKnife.Action<View>() {
        @Override
        public void apply(@NonNull View view, int index) {
            view.setOnClickListener(BusinessActivity.this);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business);
        ButterKnife.bind(this);
        ButterKnife.apply(mBtnList, CLICK_ACTION);
        ryManager = RyDrawingManager.getInstance();
        ryManager.setDrawingBusinessListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.get_battery_info:
                ryManager.getBatteryInfo();
                break;
            case R.id.get_dev_desc:
                ryManager.getDeviceDescInfo();
                break;
            case R.id.get_width:
                mTvList.get(2).setText(ryManager.getDeviceWidth()+"");
                break;
            case R.id.get_height:
                mTvList.get(3).setText(ryManager.getDeviceHeight()+"");
                break;
        }
    }

    @Override
    public void onGetBatteryInfoResponse(int resultCode, int percent, int inCharge) {
        StringBuilder sb = new StringBuilder();
        sb.append(resultCode).append(SEPRITE).append(percent).append(SEPRITE).append(inCharge);
        mTvList.get(0).setText(sb.toString());
    }

    @Override
    public void onGetDeviceVersionResponse(int resultCode, String deviceName, String version, int
            typeCode, int firmwareVersion) {
        StringBuilder sb = new StringBuilder();
        sb.append(resultCode).append(SEPRITE).append(deviceName).append(SEPRITE).append(version)
                .append(SEPRITE).append(typeCode);
        mTvList.get(1).setText(sb.toString());
    }

    public void goDrawing(View v) {
        Intent intent = new Intent(this, DrawingActivity.class);
        startActivity(intent);
    }

    public void onBackClick(View v) {
        finish();
    }
}
