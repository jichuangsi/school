package com.royole.drawingdemo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;

import com.rm.freedrawview.FreeDrawView;
import com.royole.drawinglib.RyDrawingManager;
import com.royole.drawinglib.data.PointData;
import com.royole.drawinglib.interfaces.IDrawingDataListener;

import java.util.List;


public class DrawingActivity extends Activity implements IDrawingDataListener {
    private static final String TAG = "DrawingActivity";
    public static byte[] points;
    FreeDrawView drawView;
    Handler timerHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            drawView.setDataComming(false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawing);
        drawView = (FreeDrawView) findViewById(R.id.drawing_view);
        RyDrawingManager.getInstance().setDrawingDataListener(this);
        if (points != null) {
            List<PointData.Point> pointList = RyDrawingManager.getInstance()
                    .parseRawDataToPointList(points);
            if (pointList != null) {
                for (PointData.Point point : pointList) {
                    onDrawingDataChange(point.x, point.y, point.pressure, point.time);
                }
            }
        }
    }

    @Override
    public void onDrawingDataChange(int x, int y, int p, long time) {
        if (p == 0) {
            return;
        }
        drawView.drawPoints((int) (x / 8f), (int) (y / 8f));
        drawView.setDataComming(true);
        timerHandler.removeMessages(10000);
        timerHandler.sendEmptyMessageDelayed(10000, 50);
    }

    public void onClean(View view) {
        drawView.clearDraw();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        points = null;
    }

    public void onBackClick(View v){
        finish();
    }
}
