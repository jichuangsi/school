package com.royole.drawingdemo;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.royole.drawinglib.Constant;
import com.royole.drawinglib.RyDrawingManager;
import com.royole.drawinglib.interfaces.IDrawingServiceConnectionListener;
import com.royole.drawinglib.interfaces.IPushEventListener;
import com.royole.drawinglib.interfaces.IScanListener;

import java.util.ArrayList;


public class MainActivity extends Activity implements IScanListener,
        IDrawingServiceConnectionListener, IPushEventListener {
    private static final String TAG = "MainActivity";
    RyDrawingManager mRyDrawingManager;
    private DataAdapter mDeviceAdapter;
    private ArrayList<BluetoothDevice> mDevDataList = new ArrayList<>(8);
    private ListView mListview;
    private Button mScanBtn;
    private Button mJumpBtn;
    private Button mDisconnectBtn;
    private TextView mMsgView;
    private int mCurrentConnectedState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListview = (ListView) findViewById(R.id.dev_list);
        mDeviceAdapter = new DataAdapter();
        mListview.setAdapter(mDeviceAdapter);
        mListview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (mRyDrawingManager.isLeScanning()) {
                    mRyDrawingManager.stopLeScan();
                }
                BluetoothDevice dev = mDevDataList.get(position);
                mRyDrawingManager.connectDevice(dev);    //连接设备
                Log.e(TAG, "onItemClick: ");
            }
        });
        mScanBtn = (Button) findViewById(R.id.scan_btn);
        mScanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRyDrawingManager.isLeScanning()) {
                    mRyDrawingManager.stopLeScan();
                } else {
                    mDevDataList.clear();
                    mDeviceAdapter.notifyDataSetChanged();
                    mRyDrawingManager.startScanRyDrawingDevice(10000);
                }
            }
        });
        mJumpBtn = (Button) findViewById(R.id.jump);
        mJumpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BusinessActivity.class);
                startActivity(intent);
            }
        });
        mJumpBtn.setEnabled(false);
        mDisconnectBtn = (Button) findViewById(R.id.disconnect);
        mDisconnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRyDrawingManager.disconnectDevice();
            }
        });
        mDisconnectBtn.setEnabled(false);

        mMsgView = (TextView) findViewById(R.id.msg_tv);
        initManager();
        startScan();
        mCurrentConnectedState = mRyDrawingManager.getRyConnectionState();
        mJumpBtn.setEnabled(mCurrentConnectedState == Constant.ServiceConnectionState
                .STATE_CONNECTED);
        mDisconnectBtn.setEnabled(mCurrentConnectedState == Constant.ServiceConnectionState
                .STATE_CONNECTED);
    }

    private void initManager() {
        mRyDrawingManager = RyDrawingManager.getInstance();
        //建议传Application的context，以防忘记回收导致泄露。回收资源调用RydrawingManager的destory（）方法
        mRyDrawingManager.init(RyApplication.mAppContext);
        mRyDrawingManager.setLeScanListener(this);
        mRyDrawingManager.setRyDrawingServiceConnectionListener(this);
        mRyDrawingManager.setPushEventListener(this);
    }

    private void startScan() {
        if (mRyDrawingManager.isSupportBle()) {
            if (checkBluetoothPermission(this, 1000)) {
                if (mRyDrawingManager.isBluetoothEnable()) {
                    //开始扫描带有手写板服务的设备，20000ms后自动停止扫描
                    mRyDrawingManager.startScanRyDrawingDevice(20000);
                } else {
                    Toast.makeText(this, "Please open you bluetooth!", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            Toast.makeText(this, "Sorry, you device do not support ble!", Toast.LENGTH_SHORT)
                    .show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRyDrawingManager.destroy();
    }

    @Override
    public void onDrawingServiceStateChange(int oldState, int newState) {
        Log.d(TAG, "onDrawingServiceStateChange: odlState = " + oldState + ", newState = " + "" +
                "" + "" + "" + newState);
        if (newState == Constant.ServiceConnectionState.STATE_CONNECTED) {
            Toast.makeText(MainActivity.this, "drawing service connected!", Toast.LENGTH_SHORT)
                    .show();
            if (mRyDrawingManager.isLeScanning()) {
                mRyDrawingManager.stopLeScan();
            }
            mRyDrawingManager.prepareDevice();//连接成功后要调用此方法初始化设备
        } else if (newState == Constant.ServiceConnectionState.STATE_DISCONNECTED) {
            Toast.makeText(MainActivity.this, "drawing service disconnected!", Toast
                    .LENGTH_SHORT).show();
        }
        mCurrentConnectedState = newState;
        mJumpBtn.setEnabled(mCurrentConnectedState == Constant.ServiceConnectionState
                .STATE_CONNECTED);
        mDisconnectBtn.setEnabled(mCurrentConnectedState == Constant.ServiceConnectionState
                .STATE_CONNECTED);
        mScanBtn.setEnabled(mCurrentConnectedState != Constant.ServiceConnectionState
                .STATE_CONNECTED);
    }

    @Override
    public void onNoDeviceFoundByMacError(String mac) {
        Log.d(TAG, "onNoDeviceFoundByMacError: mac = " + mac);
    }

    @Override
    public void onDrawingServiceNotFoundError() {
        Log.d(TAG, "onDrawingServiceNotFoundError: ");
    }

    @Override
    public void onLeScanStart() {
        Log.d(TAG, "onLeScanStart: ");
        mScanBtn.setText("stop scan");
    }

    @Override
    public void onLeScanEnd() {
        Log.d(TAG, "onLeScanEnd: ");
        mScanBtn.setText("start scan");
    }

    @Override
    public void onDeviceFound(BluetoothDevice device, int rssi, byte[] scanRecord) {
        Log.d(TAG, "onDeviceFound: address = " + device.getAddress() + ", name = " + device
                .getName());
        if (mDevDataList.contains(device)) {
            return;
        }
        mDevDataList.add(device);
        mDeviceAdapter.notifyDataSetChanged();
    }

    @Override
    public void onConnectDeviceByNameTimeout(String devName) {
        Log.d(TAG, "onConnectDeviceByNameTimeout: device name is: " + devName);
    }

    @Override
    public void onBluetoothConnectionStateChange(int oldState, int newState) {
        Log.d(TAG, "onBluetoothConnectionStateChange: oldState = " + oldState + ", " +
                "newState=" + newState);
    }

    @Override
    public void onLowPowerEvent(int percent) {
        Log.d(TAG, "onLowPowserEvent: percent = " + percent);
    }

    @Override
    public void onDrawingServiceConnectError(int state) {
        Log.d(TAG, "onDrawingServiceConnectError: state" + state);
    }

    @Override
    public void onButtonAClick() {
        Toast.makeText(this, "onButtonAClick", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onButtonAClick: ");
    }

    @Override
    public void onButtonBClick() {
        Toast.makeText(this, "onButtonBClick", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onButtonBClick: ");
    }

    @Override
    public void onFormatFlashDone() {
        Toast.makeText(this, "onFormatFlashDone", Toast.LENGTH_SHORT).show();
    }

    class DataAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return mDevDataList.size();
        }

        @Override
        public Object getItem(int position) {
            return mDevDataList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.list_item_layout, parent, false);
                holder = new ViewHolder();
                holder.name = (TextView) convertView.findViewById(R.id.dev_name);
                holder.mac = (TextView) convertView.findViewById(R.id.dev_mac);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            BluetoothDevice device = mDevDataList.get(position);
            holder.name.setText(device.getName());
            holder.mac.setText(device.getAddress());
            return convertView;
        }

        class ViewHolder {
            public TextView name;
            public TextView mac;
        }
    }

    public static boolean checkBluetoothPermission(Activity context, int requestCode) {
        if (Build.VERSION.SDK_INT >= 23) {
            //校验是否已具有模糊定位权限
            if (ContextCompat.checkSelfPermission(context, Manifest.permission
                    .ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(context, new String[]{Manifest.permission
                        .ACCESS_COARSE_LOCATION}, requestCode);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1000) {
            if (grantResults.length != 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mRyDrawingManager.startScanRyDrawingDevice(200000);
            } else {
                //// TODO: 2017/9/28  do tips have no permission
            }
        }
    }
}
