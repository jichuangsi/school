package com.rm.freedrawview;

/**
 * Created by Riccardo on 22/11/16.
 */

public interface PathDrawnListener {

    void onPathStart();

    void onNewPathDrawn();
}
