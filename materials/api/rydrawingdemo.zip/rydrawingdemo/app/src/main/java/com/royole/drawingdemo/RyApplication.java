package com.royole.drawingdemo;

import android.app.Application;

/**
 * File description.
 */
public class RyApplication extends Application {
    public static RyApplication mAppContext;
    @Override
    public void onCreate() {
        super.onCreate();
        mAppContext = this;
    }
}
